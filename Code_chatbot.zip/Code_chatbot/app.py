from flask import Flask, send_from_directory
import os


# Thư mục chứa file index.html (đặt app.py cạnh index.html)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))


app = Flask(__name__, static_folder=BASE_DIR, static_url_path="")


@app.route("/")
def root():
	"""Trả về file index.html (blog pastel)."""
	return send_from_directory(BASE_DIR, "index.html")


@app.route("/health")
def health():
	return {"status": "ok"}


if __name__ == "__main__":
	# Chạy server đơn giản để xem blog tại http://127.0.0.1:5000
	app.run(host="0.0.0.0", port=5000, debug=True)